﻿using System.Text;
using SDRSharp.Radio;

namespace SDRSharp.RdsiPlugin
{
    public unsafe class RdsHwnd : IRdsBitStreamProcessor, IBaseProcessor
    {
        private bool _enabled = true;
        private readonly RdsiPluginPanel _rdsiPluginPanel;
        private StringBuilder _sb = new StringBuilder();

        public RdsHwnd(RdsiPluginPanel _rdsPanelRef)
        {
            _rdsiPluginPanel = _rdsPanelRef;
        }

        public bool Enabled
        {
            get
            {
                return _enabled;
            }
            set
            {
                _enabled = value;
            }
        }
        public void Process(ref RdsFrame _rdsFrame)
        {
            _rdsFrame.Filter = false;
            string pic = string.Format("{0:X}", _rdsFrame.GroupA).Trim();
            if (pic.Length != 4)
                return;
            _sb.Clear();
            _sb.Append(string.Format("{0:X}", _rdsFrame.GroupA));
            _sb.Append(string.Format("{0:X}", _rdsFrame.GroupB));
            _sb.Append(string.Format("{0:X}", _rdsFrame.GroupC));
            _sb.Append(string.Format("{0:X}", _rdsFrame.GroupD));
            _sb.Append("\r\n");
            _rdsiPluginPanel.WriteToFile(_sb.ToString(), pic);
        }
    }

}

