﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using SDRSharp.Common;
using SDRSharp.Radio;

namespace SDRSharp.RdsiPlugin
{
    public partial class RdsiPluginPanel : UserControl
    {
        private bool _writeFile = false;
        private readonly ISharpControl _control;
        private StreamWriter _sw = null;

        public RdsiPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            _control = control;
            labelPicode.Text = "";
            textBoxLogFile.Text = "";
        }

        public void WriteToFile(String groups, String picode)
        {
            if (_writeFile)
            {
                _sw.Write(groups);
                labelPicode.Text = picode;
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            _writeFile = false;
            textBoxLogFile.Text = "";
            labelPicode.Text = "";
            if (_sw == null)
            {
                String lf = Application.StartupPath + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") +
                "_" + _control.Frequency.ToString() + ".spy";
                try
                {
                    _sw = new StreamWriter(lf, true);
                }
                catch (IOException ex)
                {
                    textBoxLogFile.Text = ex.Message;
                    return;
                }
                buttonStart.Enabled = false;
                buttonStop.Enabled = true;
                textBoxLogFile.Text = lf;
                _writeFile = true;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            _writeFile = false;
            labelPicode.Text = "";
            textBoxLogFile.Text = "";
            _sw.Close();
            _sw.Dispose();
            _sw = null;
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
        }

        public void Close()
        {
            if (_sw != null)
            {
                _sw.Close();
            }
        }
    }
}
